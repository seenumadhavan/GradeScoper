var api_script = document.getElementById('google_api');
api_script.onload = function(){};handleClientLoad();