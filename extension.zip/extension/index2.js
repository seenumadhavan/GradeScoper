chrome.identity.getAuthToken({interactive: true}, function(token) {
    console.log('got the token', token);
  })

// Client ID and API key from the Developer Console
//var CLIENT_ID = '1022143948638-summ8v5j6gv01njsturknvn6opm21ooc.apps.googleusercontent.com';
var CLIENT_ID = '1022143948638-71r875hpsahco2atmtfllnd3cvnadlmp.apps.googleusercontent.com';
var API_KEY = 'AIzaSyAB-EKRa9es0KscUhWe4F5jwi4-KSumdSM';

// Array of API discovery doc URLs for APIs used by the quickstart
var DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest"];

// Authorization scopes required by the API; multiple scopes can be
// included, separated by spaces.
var SCOPES = "https://www.googleapis.com/auth/calendar";

var authorizeButton = document.getElementById('authorize_button');
var signoutButton = document.getElementById('signout_button');
//var createCalendarButton = document.getElementById('create_calendar_button');
var createEventButton = document.getElementById('create_event_button');
var listEventsButton = document.getElementById('list_events_button');

// document.addEventListener('DOMContentLoaded', function () {
//     console.log("hi");
//     handleClientLoad();      
// });
/**
 *  On load, called to load the auth2 library and API client library.
 */
function handleClientLoad() {
gapi.load('client:auth2', initClient);
}

/**
 *  Initializes the API client library and sets up sign-in state
 *  listeners.
 */
function initClient() {
gapi.client.init({
    apiKey: API_KEY,
    clientId: CLIENT_ID,
    discoveryDocs: DISCOVERY_DOCS,
    scope: SCOPES
}).then(function () {
    // Listen for sign-in state changes.
    gapi.auth2.getAuthInstance().isSignedIn.listen(updateSigninStatus);

    // Handle the initial sign-in state.
    updateSigninStatus(gapi.auth2.getAuthInstance().isSignedIn.get());
    authorizeButton.onclick = handleAuthClick;
    signoutButton.onclick = handleSignoutClick;
    // createCalendarButton.onclick = handleCreateCalendar;
    createEventButton.onclick = create_event;
    listEventsButton.onclick = listUpcomingEvents;
}, function(error) {
    appendPre(JSON.stringify(error, null, 2));
});
}

/**
 *  Called when the signed in status changes, to update the UI
 *  appropriately. After a sign-in, the API is called.
 */
function updateSigninStatus(isSignedIn) {
if (isSignedIn) {
    authorizeButton.style.display = 'none';
    signoutButton.style.display = 'block';
    //createCalendarButton.style.display = 'block';
    createEventButton.style.display = 'block';
    listEventsButton.style.display = 'block';

    // INSERT DEFAULT FUNCTION CALLS HERE (WILL RUN UPON STARTUP)
    // listUpcomingEvents();
    // create_event();
    // listUpcomingEvents();
    

} else {
    authorizeButton.style.display = 'block';
    signoutButton.style.display = 'none';
    //createCalendarButton.style.display = 'none';
    createEventButton.style.display = 'none';
    listEventsButton.style.display = 'none';
}
}

/**
 *  Sign in the user upon button click.
 */
function handleAuthClick(event) {
gapi.auth2.getAuthInstance().signIn();
}

/**
 *  Sign out the user upon button click.
 */
function handleSignoutClick(event) {
gapi.auth2.getAuthInstance().signOut();
}

/**
 * Append a pre element to the body containing the given message
 * as its text node. Used to display the results of the API call.
 *
 * @param {string} message Text to be placed in pre element.
 */
function appendPre(message) {
var pre = document.getElementById('content');
var textContent = document.createTextNode(message + '\n');
pre.appendChild(textContent);
}

/**
 * Print the summary and start datetime/date of the next ten events in
 * the authorized user's calendar. If no events are found an
 * appropriate message is printed.
 */
async function listUpcomingEvents(event) {
var gradescoperCalID = await getGradescoperCalendar();
console.log(gradescoperCalID);
gapi.client.calendar.events.list({
    'calendarId': gradescoperCalID,
    'timeMin': (new Date()).toISOString(),
    'showDeleted': false,
    'singleEvents': true,
    'maxResults': 10,
    'orderBy': 'startTime'
}).then(function(response) {
    var events = response.result.items;
    appendPre('Upcoming events:');

    if (events.length > 0) {
    for (i = 0; i < events.length; i++) {
        var event = events[i];
        var when = event.start.dateTime;
        if (!when) {
        when = event.start.date;
        }
        appendPre(event.summary + ' (' + when + ')')
    }
    } else {
    appendPre('No upcoming events found.');
    }
});
}

/*
Create event on call
*/
async function create_event(event) {
var gradescoperCalID = await getGradescoperCalendar();
console.log(gradescoperCalID);
var event = {
    'summary': 'Google I/O 2077',
    'location': '800 Howard St., San Francisco, CA 94103',
    'description': 'A chance to hear more about Google\'s developer products.',
    'start': {
    'dateTime': '2020-12-26T09:00:00-07:00',
    'timeZone': 'America/Los_Angeles'
    },
    'end': {
    'dateTime': '2020-12-26T17:00:00-07:00',
    'timeZone': 'America/Los_Angeles'
    },
    'recurrence': [
    'RRULE:FREQ=DAILY;COUNT=1'
    ],
    'reminders': {
    'useDefault': false,
    'overrides': [
        {'method': 'email', 'minutes': 24 * 60},
        {'method': 'popup', 'minutes': 10}
    ]
    }
};

var request = gapi.client.calendar.events.insert({
    'calendarId': gradescoperCalID,
    'resource': event
});
request.execute(function(event) {
    appendPre('Event created: ' + event.htmlLink);
    console.log("event created");
});
}

/*Creates a calendar*/
function create_calendar() {
return gapi.client.calendar.calendars.insert({
    "resource": {
    "summary": "GradeScoper"
    }
})
    .then(function(response) {
    // Handle the results here (response.result has the parsed body).
    // console.log("Response", response);
    console.log("created calendar");
    return JSON.parse(response.body).id;
    },
    function(err) { console.error("Execute error", err); });
}

// function to create calendar if doesn't exist, and ultimately return calendar ID (for future event creation)
function getGradescoperCalendar() {
var response_raw;
var cal_id;
var cal_found = false;
//   const response = await gapi.client.calendar.calendarList.list({});
//   response_raw = response;
//   var cal_items = JSON.parse(response_raw.body).items;
//   // console.log(cal_found);
//   for (var i = 0; i < cal_items.length; i++) {
//     if (cal_items[i].summary == "GradeScoper") {
//       cal_id = cal_items[i].id;
//       console.log("found");
//       cal_found = true;
//     }
//   }
//   if (cal_found) return cal_id;
//   return create_calendar();
// }

return gapi.client.calendar.calendarList.list({})
    .then(function(response) {
            // Handle the results here (response.result has the parsed body).
            // console.log("Response", response);
            response_raw = response;
            var cal_items = JSON.parse(response_raw.body).items;
            // console.log(cal_found);
            for (var i = 0; i < cal_items.length; i++) {
            if (cal_items[i].summary == "GradeScoper") {
                cal_id = cal_items[i].id;
                console.log("found");
                cal_found = true;
            }
            }
            if (cal_found) return cal_id;
            return create_calendar();
        },
        function(err) { console.error("Execute error", err); });
// console.log(typeof(response_raw));
}
        
      